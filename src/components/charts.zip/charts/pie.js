/**饼图封装**/
import {BaseChart} from './baseChart.js'

class PieChart extends BaseChart {
    
    //占比饼图
    pie(){
        var legenddata = this.ydata;
        var series = [];
        var seriesData = [];
        var sum = 0; //总和
        
        //求和
        this.vdata.forEach((val, index) => {
            sum += val[0];
        });
        
        //重构vdata数据
        this.vdata.forEach((val, index) => {
            var per = Math.round(val[0] / sum * 10000) / 100;
            if (!this.ydata[index]) { 
                this.ydata[index] = "未填";
            }
            var obj = { name: this.ydata[index], value: per };
            seriesData.push(obj);
        });
        //其它series配置项
        var config = {
            name: '占比',
            type: 'pie',
            label: { normal: { formatter: '{b}({c})' } },
            radius: [0, '60%'],
            center: ['50%', '60%'],
            data: seriesData
        }
        series.push(config);

        var option = {
            title: {
                text: this.title,
                x: 'center',
                textStyle: {
                    color: '#333',
                    fontWeight: 'normal',
                    fontSize: '16'
                },
                top: 16,
                padding: [0, 12, 0]
            },
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            series: series
        };
        
        return option;
    }

}

//导出
export { PieChart }