/**地图封装**/

class MapChart{
    //构建器
    constructor(data, panelId){
        this.panelId = panelId;
        this.data = data;
        this.title = this.data.title || "";
        this.xdata = this.data.xdata || [];
        this.ydata = this.data.ydata || [];
        this.vdata = this.data.vdata || [];
        this.legenddata = this.data.legenddata || [];
    }

    //占比饼图
    drawMap(){
        var chart = echarts.init(document.getElementById(this.panelId), "macarons");
        var seriesData = [];

        this.vdata.forEach((val, index) => {
            var d = {
                name: val.name, value: val.value,
                itemStyle: {
                    normal: {
                        areaColor: "#349eea",
                        borderColor: "#fff"
                    },
                    emphasis: {
                        areaColor: "#349eea",
                        borderColor: "#fff"
                    }
                }
            };
            seriesData.push(d);
        });

        var option = {
            tooltip: {
                trigger: 'item',
                show: false
            },
            dataRange: {
                min: 0,
                max: 50,
                x: 'left',
                y: 'bottom',
                text: ['多', '少'], // 文本，默认为数值文本
                calculable: true,
                color: ['#5ab1ef', '#2ec7c9']//值域颜色349eea
            },
            series: [
                {
                    name: 'name',
                    type: 'map',
                    mapType: 'china',
                    zoom: 1.2,
                    selectedMode: 'single',
                    label: {
                        normal: {
                            show: true,
                            formatter: function (data) {
                                if (data.value) {
                                    return data.name + data.value;
                                } else {
                                    return data.name;
                                }
                            }
                        },
                        emphasis: {
                            show: true,
                            color: "#000"
                        }
                    },
                    itemStyle: {
                        normal: {
                            borderColor: '#ccc',
                            areaColor: '#f3f3f3',
                        },
                        emphasis: {
                            borderColor: '#ccc',
                            areaColor: '#f3f3f3'
                        }
                    },
                    data: seriesData
                }
            ]
        };
        
        chart.setOption(option);
        
        //屏幕大小改变
        window.addEventListener("resize", ()=>{ chart.resize(); });

        return this;
    }

}

//导出
export default{
    MapChart
}