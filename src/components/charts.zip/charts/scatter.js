/**散点图封装**/
import {BaseChart} from './baseChart.js'

class ScatterChart extends BaseChart {
    
    //散点图对比
    scatterComp(){
        let series = [];
    
        this.vdata.forEach((val,index) => {
            let emptyArr = []; //新建空数组
            emptyArr.push(val);
            
            let config = {
                name: this.legenddata[index],
                data: emptyArr, 
                type: 'scatter', 
                symbolSize: 41, 
                label: { normal: 
                    { show: true, formatter: this.legenddata[index], position: 'top' } 
                }
            }
            series.push(config);
        
        });
    
        let option = {
            title: {
                text: this.title,
                right:'center'
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    saveAsImage: { show: true,backgroundColor:'#ffffff' }
                }
            },
            grid: {
                top:'20%',
                left: '5%',
                right: '4%',
                bottom: '12%',
                containLabel: true
            },
            legend: {
                data: this.legenddata,
                type:'scroll',
                top:'8%'
            },
            xAxis: {
                name: this.xAxis,
                nameLocation:'middle',
                nameGap:'30',
                axisLine:{lineStyle:{color:'#000'}},
                axisLabel:{textStyle:{color:'#000'}},
                splitLine: {
                    lineStyle: {
                        type: 'dashed'
                    }
                }
            },
            yAxis: {
                name: this.yAxis,
                nameLocation:'middle',
                nameGap:45,axisLine:{lineStyle:{color:'#000'}},axisLabel:{textStyle:{color:'#000'}},
                splitLine: {
                    lineStyle: {
                        type: 'dashed'
                    }
                },
                scale: true
            },
            series: series
        };

        return option;
    }

    //散点图(占比)
    scatterE(){
        let legshow = this.legenddata.length<=20;
        let series = [];
        
        this.vdata.forEach((val,index) => {
            let emptyArr = [];
            emptyArr.push(val);
            
            let config = {
                name: this.legenddata[index],
                data: emptyArr, 
                type: 'scatter', 
                symbolSize: 41, 
                label: { normal: 
                    { show: true, formatter: this.legenddata[index], position: 'top' } 
                }
            }
            series.push(config);
        
        });
        
        let option = {
            title: {
                text: this.title,
                right:'center'
            },
            tooltip:{
                formatter:function(p){
                    return (p.componentType=="series") ? "x : "+p.data[0]+"<br/>y : "+p.data[1] : "";
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    saveAsImage: { show: true,backgroundColor:'#ffffff' }
                }
            },
            grid: {
                top:'20%',
                left: '3%',
                right: '4%',
                bottom: '10%',
                containLabel: true
            },
            legend: {
                show:legshow, 
                data: this.legenddata,
                type:'scroll',
                top:'8%'
            },
            xAxis: {
                name: this.xAxis,
                nameLocation:'middle',
                nameGap:'30',
                axisLine:{lineStyle:{color:'#000'}},
                axisLabel:{textStyle:{color:'#000'}},
                splitLine: {
                    lineStyle: {
                        type: 'dashed'
                    }
                }
            },
            yAxis: {
                name: this.yAxis,
                nameLocation:'middle',
                nameGap:30,
                axisLine:{lineStyle:{color:'#000'}},
                axisLabel:{textStyle:{color:'#000'}},
                splitLine: {
                    lineStyle: {
                        type: 'dashed'
                    }
                },
                scale: true
            },
            series: [
                {name: '2013', data: [[188521858,53.5,'2013']], type: 'scatter', symbolSize: 30,  label: { normal: { show: true, formatter: '2013', position: 'top' } }, },
                {name: '2014', data: [[220658940,56.2,'2014']], type: 'scatter', symbolSize: 30,  label: { normal: { show: true, formatter: '2014', position: 'top' } }, },
                {name: '2015', data: [[227748158,56.7,'2015']], type: 'scatter', symbolSize: 30,  label: { normal: { show: true, formatter: '2015', position: 'top' } }, },
                {name: '2016', data: [[187633788,57.2,'2016']], type: 'scatter', symbolSize: 30,  label: { normal: { show: true, formatter: '2016', position: 'top' } }, }
            ]
        };

        return option;
    }

}

//导出
export {ScatterChart}